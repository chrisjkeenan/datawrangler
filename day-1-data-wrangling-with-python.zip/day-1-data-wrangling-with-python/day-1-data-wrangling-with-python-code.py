#######################################################
#######################################################
############    COPYRIGHT - DATA SOCIETY   ############
#######################################################
#######################################################

## DAY 1 DATA WRANGLING WITH PYTHON/DAY 1 DATA WRANGLING WITH PYTHON ##

## NOTE: To run individual pieces of code, select the line of code and
##       press ctrl + enter for PCs or command + enter for Macs


#=================================================-
#### Slide 27: Refresh on basic coding in Python  ####

# Store variables.
name = 'Mike'
a, b, c = 1, 2, 3

# Print a variable out.
print(a)
# Swap variable values.
a, b = b, a

# Delete a variable.
del a
# Slice a string
letters = 'ABCDEFGH'
print(letters[2:5])
# Length of a string
print(len(letters))
print(type(letters))


#=================================================-
#### Slide 31: User-defined functions in Python  ####

# Define a function that prints the value of `Pi`. 
def PrintPi():     #<- function name
    print(3.14)    #<- action to perform
PrintPi()


#=================================================-
#### Slide 32: Functions in Python with 1 or more arguments  ####

# Define a function that prints the value of `Pi`
# and takes a number of decimal points to which we want to round the number.
def PrintPi(num_decimals):               #<- function name + argument(s)
    pi = 3.14159265359                   #<- action to perform
    rounded_pi = round(pi, num_decimals) #<- action to perform
    print(rounded_pi)                    #<- action to perform
    
# Print value of pi rounded to 4 decimal points.
PrintPi(4)


#=================================================-
#### Slide 33: Functions in Python that return a value  ####

# Define a function that prints the value of `Pi`,
# takes a number of decimal points to which we want to round the number,
# and returns the value back to us.
def GetPi(num_decimals):                 #<- function name + argument(s)
    pi = 3.14159265359                   #<- action to perform
    rounded_pi = round(pi, num_decimals) #<- action to perform
    return rounded_pi                    #<- value to return


#=================================================-
#### Slide 34: Functions in Python that return a value (cont'd)  ####

# Return a value of pi rounded to 4 decimal points.
print(GetPi(4)) 

# Return a value of pi rounded to 4 decimal points.
# Assign it to a variable.
pi_4 = GetPi(4)
print(pi_4)



#=================================================-
#### Slide 36: Functions in Python: MakeFullName  ####

# Define a function that concatenates 
# first and last names.
def MakeFullName(first_name, last_name):
    full_name = first_name + ' ' + last_name
    return full_name


#=================================================-
#### Slide 37: Functions in Python: calling a function  ####

# Call the function.
print(MakeFullName("Harry", "Potter"))
# Call the function and save 
# output to variable.
output_name = MakeFullName("Harry", "Potter")
print(output_name)


#=================================================-
#### Slide 38: Functions in Python: EvaluateCarPrice  ####

def EvaluateCarPrice(price):
    if price > 38000:
        action = "Leave the dealership immediately, this is a rip off!"
    elif price > 22000 and price <= 38000 :
        action = "Take the car and go celebrate, you can afford it!"
    else:
        action = "Leave the dealership immediately, this is a scam!"
    return action


#=================================================-
#### Slide 39: Functions in Python: calling a function  ####

# Let's set the price of a car to $45,000.
price = 45000
action1 = EvaluateCarPrice(price)
print(action1)

# Let's set the price of a car to $32,000.
price = 32000
action2 = EvaluateCarPrice(price)
print(action2)

# Let's set the price of a car to $5,000.
price = 5000
action3 = EvaluateCarPrice(price)
print(action3)


#=================================================-
#### Slide 40: Functions that return two or more values  ####

def MostProfitableMonth(sales_data):

    biggest_amt = 0
    biggest_month = None
    
    for month, amt in sales_data.items():
        if amt >= biggest_amt:
            biggest_amt = amt
            biggest_month = month
            
    return (biggest_month, biggest_amt) 


#=================================================-
#### Slide 41: Functions that return two or more values (cont'd)  ####

# Let's define a dictionary with sales data.
year_sales = {'January': 1045, 'February': 1008, 'March': 1025, 
                    'April': 1080, 'May': 1100, 'June': 1050, 'July': 1050,
                    'August': 950, 'September': 1010, 'October': 1500, 
                    'November': 1450, 'December': 1380}
# Assign output of function to variables in correct order.
best_sales_month, best_sales_amt = MostProfitableMonth(year_sales)
print("Best month:", best_sales_month)
print("Best amount:", best_sales_amt)


#=================================================-
#### Slide 42: Passing a list as an argument  ####

# Define a function that returns the length of all character strings in a list.
def calculate_lengths(list_of_strings):
  # Define an empty list to store the result.
  lengths = []
  # Use a for loop to access items in the input list.
  for item in list_of_strings:
    lengths.append(len(item))
  
  return lengths
result = calculate_lengths(["Monday", "Tuesday", "Saturday"])
print(result)


#=================================================-
#### Slide 43: Functions that have default arguments  ####

def MostProfitableMonth(sales_data, verbose = True):

    biggest_amt = 0
    biggest_month = None
    
    for month, amt in sales_data.items():
        if amt >= biggest_amt:
            biggest_amt = amt
            biggest_month = month
            
    if verbose:
        print('The best sales month was', biggest_month, 'with amount sold equal to', biggest_amt)
        
    return (biggest_month, biggest_amt) 


#=================================================-
#### Slide 44: Functions that have default arguments (cont'd)  ####

# Assign output of function to variables in correct order.
best_sales_month, best_sales_amt = MostProfitableMonth(year_sales)
# Assign output of function to variables in correct order.
best_sales_month, best_sales_amt = MostProfitableMonth(year_sales, False)
print("Best month:", best_sales_month, "Best amount:", best_sales_amt)


#=================================================-
#### Slide 46: Anonymous functions: Syntax  ####

print((lambda v: v + " the 5th of November!")("Remember"))


#=================================================-
#### Slide 47: Anonymous functions with multiple arguments  ####

remember = lambda v: v + " the 5th of November!"
print(remember("Remember"))
y = lambda a, b: a + b
print(y(765, -987))



#=================================================-
#### Slide 48: Function within another function  ####

# Define a function to check if a number is even or odd.
def even_odd(num):
  if num%2 == 0:           #<- % is the Modulo operator.
    result = "Even"
  else:
    result = "Odd"
  return result
# Define a function to print if each element of a list is even or odd.
def even_odd_list(numbers):
  for num in numbers:
    result = even_odd(num)   #<- Call function on num an assign its result
    print(num, ": ", result)

even_odd_list([22,41,16,13])


#=================================================-
#### Slide 50: Exercise 1  ####




#######################################################
####  CONGRATULATIONS ON COMPLETING THIS MODULE!   ####
#######################################################
