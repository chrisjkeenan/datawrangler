#######################################################
#######################################################
############    COPYRIGHT - DATA SOCIETY   ############
#######################################################
#######################################################

## DAY 4 DATA WRANGLING WITH PYTHON/DAY 4 DATA WRANGLING WITH PYTHON ##

## NOTE: To run individual pieces of code, select the line of code and
##       press ctrl + enter for PCs or command + enter for Macs


#=================================================-
#### Slide 4: Import Pandas and os  ####

import pandas as pd
import numpy as np
import os


#=================================================-
#### Slide 5: Directory settings  ####

# Set `main_dir` to the location of your `skill-soft` folder (for Linux).
main_dir = "/home/[username]/Desktop/skill-soft"
# Set `main_dir` to the location of your `skill-soft` folder (for Mac).
main_dir = '/Users/[username]/Desktop/skill-soft'
# Set `main_dir` to the location of your `skill-soft` folder (for Windows).
main_dir = "C:\\Users\\[username]\\Desktop\\skill-soft"
# Make `data_dir` from the `main_dir` and 
# remainder of the path to data directory.
data_dir = main_dir + "/data"


#=================================================-
#### Slide 6: Setting working directory  ####

# Set working directory.
os.chdir(data_dir)
# Check working directory.
print(os.getcwd())


#=================================================-
#### Slide 7: Read data from csv file  ####

household_poverty = pd.read_csv('household_poverty.csv')
print(household_poverty.head())


#=================================================-
#### Slide 8: Inspect data   ####

print(type(household_poverty))  #<- a pandas dataframe!

print(len(household_poverty))   #<- returns the number of rows
# You can also save the shape of the dataframe into 2 variables 
# (since the returned is a tuple with 2 values).

nrows, ncols = household_poverty.shape
print(nrows)
print(ncols)


#=================================================-
#### Slide 9: Previewing data - using head method  ####

print(household_poverty.head())  #<- pulls the first 5 rows (the default is 5)


#=================================================-
#### Slide 10: Previewing data - using head method  ####

print(household_poverty.head(3)) #<- pulls the first 3 rows


#=================================================-
#### Slide 11: Previewing data - using sample method  ####

print(household_poverty.sample(n = 3))      #<- 3 random rows


#=================================================-
#### Slide 12: Previewing data - using sample method  ####

print(household_poverty.sample(frac = .02)) #<- a random 2% of the rows


#=================================================-
#### Slide 13: Reviewing household_poverty data  ####

print(household_poverty.columns)
print(household_poverty.dtypes)


#=================================================-
#### Slide 14: Reviewing household_poverty data - info  ####

print(household_poverty.info())  


#=================================================-
#### Slide 15: Reviewing household_poverty data - describe  ####

print(household_poverty.describe())


#=================================================-
#### Slide 16: Reviewing household_poverty data - index  ####

print(household_poverty.index)
household_poverty = household_poverty.set_index('hh_ID')
print(household_poverty.index)


#=================================================-
#### Slide 17: Looking up by household ID  ####

# Look up a specific row by index.
print(household_poverty.loc['21eb7fcc1'])


#=================================================-
#### Slide 18: Looking up by household ID  ####

# Look up a specific row by index.
print(household_poverty.iloc[1])


#=================================================-
#### Slide 19: Reset index  ####

household_poverty = household_poverty.reset_index()


#=================================================-
#### Slide 21: Exercise 1  ####




#=================================================-
#### Slide 24: Splitting using groupby()  ####

grouped = household_poverty.groupby('rooms')
print(grouped.first())


#=================================================-
#### Slide 26: Groupby() and summary functions  ####

# We are counting the number of hh_IDs by number of rooms, and creating a dataframe.
hh_ID = grouped.count()[['hh_ID']]
print(hh_ID)
# This syntax would do the same, but create a series.
print(grouped.count().hh_ID)


#=================================================-
#### Slide 27: A little more about summarizing - sorting  ####

print(hh_ID.sort_values(by = ['hh_ID'], ascending = [False]))


#=================================================-
#### Slide 28: A little more about summarizing - filtering  ####

print(hh_ID.query('rooms < 5'))


#=================================================-
#### Slide 29: A little more about summarizing - new columns  ####

over100_hh = hh_ID['hh_ID'] > 100
# Add the new column.
hh_ID['over100_hh'] = over100_hh
print(hh_ID.head())


#=================================================-
#### Slide 31: Exercise 2  ####




#=================================================-
#### Slide 34: Load the dataset  ####

household_poverty = pd.read_csv("costa_rica_poverty.csv")
print(household_poverty.head())


#=================================================-
#### Slide 36: Subsetting data  ####

costa_viz = household_poverty[['ppl_total', 'dependency_rate',
                               'num_adults', 'rooms', 'age', 'monthly_rent',
                               'Target']]
print(costa_viz.head())


#=================================================-
#### Slide 37: Data prep: clean NAs  ####

print(costa_viz.isnull().sum())


#=================================================-
#### Slide 38: Data cleaning: NAs  ####

# Set the dataframe equal to the imputed dataset.
costa_viz = costa_viz.fillna(costa_viz.mean())
# Check how many values are null in monthly_rent.
print(costa_viz.isnull().sum())


#=================================================-
#### Slide 39: Converting the target variable  ####

costa_viz['Target'] = np.where(costa_viz['Target'] <= 3, 'vulnerable', 'non_vulnerable')
print(costa_viz['Target'].head())


#=================================================-
#### Slide 40: Data prep: target  ####

print(costa_viz.Target.dtypes)
costa_viz["Target"] = np.where(costa_viz["Target"] == "non_vulnerable", True, False)

# Check class again.
print(costa_viz.Target.dtypes)


#=================================================-
#### Slide 44: Prepare data: group and summarize (cont'd)  ####

# Group data by `Target` variable.
grouped = costa_viz.groupby('Target')

# Compute mean on the listed variables using the grouped data.
costa_grouped_mean = grouped.mean()[['ppl_total','dependency_rate','num_adults','rooms','age']]
print(costa_grouped_mean)


#=================================================-
#### Slide 45: Prepare data: group and summarize (cont'd)  ####

# Reset index of the dataset.
costa_grouped_mean = costa_grouped_mean.reset_index()
print(costa_grouped_mean)


#=================================================-
#### Slide 48: Wide to long format: melt (cont'd)  ####

# Melt the wide data into long.
costa_grouped_mean_long = pd.melt(costa_grouped_mean,       #<- wide dataset
                                  id_vars = ['Target'],     #<- identifying variable
                                  var_name = 'metric',      #<- contains col names of wide data
                                  value_name = 'mean')      #<- contains values from above columns
print(costa_grouped_mean_long)



#=================================================-
#### Slide 50: Long to wide format: pivot (cont'd)  ####

# Melt the long data into wide.
costa_grouped_mean_wide = costa_grouped_mean_long.pivot(
                                                    index = 'Target',   #<- identifying variable
                                                    columns = 'metric', #<- col names of wide data
                                                    values = 'mean')    #<- values from above columns
print(costa_grouped_mean_wide)


#=================================================-
#### Slide 52: Exercise 3  ####




#######################################################
####  CONGRATULATIONS ON COMPLETING THIS MODULE!   ####
#######################################################
