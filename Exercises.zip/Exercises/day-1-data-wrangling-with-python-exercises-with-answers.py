#!/usr/bin/env python
# coding: utf-8

# # Day 1 - Data wrangling with Python - Exercises with answers

# ## Exercise 1
# 
# #### Question 1
# ##### Assign variable `x` as your age and variable `y` as your neighbor's age.
# ##### Print `x` and `y`. 
# ##### Now swap `x` and `y` and print the result.

# In[1]:


x = 24
y = 20
print("x:", x, "y:", y)
x, y = y, x
print("x:", x, "y:", y)


# #### Question 2
# ##### Create a variable `numbers` with values 12345 as a string
# ##### Print the first and last elements in `numbers`
# ##### Print the length of the `numbers`.
# ##### Convert the type of `numbers` to integer
# ##### Print the type to verify your answer

# In[3]:


numbers = "12345"
print("The first element is:",numbers[0], "\nThe last element is:", numbers[-1])


# In[4]:


print("Length:", len(numbers))
numbers = int(numbers)
print(type(numbers))


# #### Question 3
# ##### Create a `PrintHello` function so that it takes a name of a person as an argument and prints "Hello, [name]!".
# ##### Call the function to test whether it is working properly. Try out a few different names. 
# 
# #### Answer:

# In[5]:


def PrintHello(x):
    print('Hello, ' + x + '!')
    
PrintHello('John')


# #### Question 4
# ##### Modify the function from Question 2 and name it `GetHelloMessage` so that it returns the message to be printed, but doesn't print it.
# ##### Call the function, assign its output to a variable `output_message` and then print the `output_message`.
# 
# #### Answer:

# In[6]:


def GetHelloMessage(x):
    return 'Hello, ' + x + '!'
    
output_message = GetHelloMessage('John')
print(output_message)


# #### Question 5
# ##### Create a function called `find_range()` that takes a parameter `x`.
# ##### Return two numbers `x-10` and `x+10`.
# ##### Call the function by passing 25 to the function.
# 
# #### Answer:

# In[7]:


def find_range(x):
    return x-10, x+10

find_range(25)


# #### Question 6
# ##### Create a function named `find_sum` that takes two parameters `a` and `b` and returns their sum.
# ##### Let `a` have a default value equal to 3 and `b` have a default value equal to 2.
# ##### Call the function without providing any arguments. What value do you get as a result?
# ##### Call the function by giving it the 2 arguments: 7 and 10.
# ##### Call the function providing a single argument 9 to the function. What value do you get in return?
# 
# #### Answer:

# In[8]:


def find_sum(a=3, b=2):
    return a + b

print(find_sum())
print(find_sum(7,10))
print(find_sum(9))


# #### Question 7
# ##### Create an anonymous function that returns a reversed string and assign it to `palindrome` variable.
# ##### Call the function and use "No lemon, no melon" as the input and print the result.
# 
# #### Answer:

# In[9]:


palindrome = lambda v : v[::-1]
print(palindrome("No lemon, no melon"))


# #### Question 8
# ##### Create a function called `factorial` which returns the factorial value of the given number `x`.
# ##### Call the function to print the factorial of 5, try a few other values.
# ##### _Hint: 4 factorial (4!) = 4 x 3 x 2 x 1 = 24._
# 
# #### Answer:

# In[10]:


def factorial(x):
    result = 1
    while x > 0:
        result = x * result
        x = x - 1
    return result

factorial(4)


# In[ ]:




